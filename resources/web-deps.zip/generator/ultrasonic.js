/**
 * @license
 * Arduino code generator for Ultrasonic Sensor blocks using NewPing library.
 * Added user-defined max distance and simplified to cm only.
 */
'use strict';

// Ensure Blockly and the Arduino generator are loaded
if (typeof Blockly === 'undefined' || !Blockly.Arduino) {
    throw new Error('Blockly or Blockly.Arduino is not loaded!');
}

Blockly.Arduino['sensor_ultrasonic_init'] = function(block) {
  // Get the actual variable object, not just the ID
  var variable = Blockly.Variables.getVariable(block.workspace, block.getFieldValue('SONAR_VAR'));
  // Use the clean variable name directly from the variable object
  var variable_sonar_var = variable.name;
  
  // Get the pin numbers and max distance chosen by the user
  var dropdown_trig_pin = block.getFieldValue('TRIG_PIN');
  var dropdown_echo_pin = block.getFieldValue('ECHO_PIN');
  var max_distance = block.getFieldValue('MAX_DIST') || '200'; // Default to 200 if not set

  // Add the include for the library at the top level
  Blockly.Arduino.includes_['include_newping'] = '#include <NewPing.h>';

  // Make a clean variable identifier for C++ code
  var clean_var_name = variable_sonar_var.replace(/[^a-zA-Z0-9_]/g, '_');
  
  // Define the NewPing object instance after the pin definitions
  Blockly.Arduino.definitions_['var_sonar_' + clean_var_name] =
    `NewPing ${clean_var_name}(${dropdown_trig_pin}, ${dropdown_echo_pin}, ${max_distance}); // Ultrasonic sensor ${clean_var_name} uses trig=${dropdown_trig_pin}, echo=${dropdown_echo_pin}, max_distance=${max_distance}cm`;

  return ''; // This block only defines things
};

Blockly.Arduino['sensor_ultrasonic_read'] = function(block) {
  // Get the actual variable object, not just the ID
  var variable = Blockly.Variables.getVariable(block.workspace, block.getFieldValue('SONAR_VAR'));
  // Use the clean variable name directly from the variable object
  var variable_sonar_var = variable.name;
  
  // Make a clean variable identifier for C++ code
  var clean_var_name = variable_sonar_var.replace(/[^a-zA-Z0-9_]/g, '_');

  // Generate a call to the specific function for this sensor instance
  var funcName = 'readUltrasonicDistance_' + clean_var_name;

  // Define the distance reading function if not already defined
  if (!Blockly.Arduino.definitions_['func_' + funcName]) {
      // Check if we can find the initialization block
      var initFound = Blockly.Arduino.definitions_['var_sonar_' + clean_var_name] !== undefined;
      
      if (!initFound) {
          console.warn(`Ultrasonic read for '${variable_sonar_var}' called without proper initialization.`);
          
          // Create fallback definitions - assuming default pins if missing init block
          var trigPin = 12;  // Default fallback
          var echoPin = 11;  // Default fallback
          var defaultMaxDist = 200; // Default max distance
          
          Blockly.Arduino.includes_['include_newping'] = '#include <NewPing.h>';
          Blockly.Arduino.definitions_['var_sonar_' + clean_var_name] = 
              `NewPing ${clean_var_name}(${trigPin}, ${echoPin}, ${defaultMaxDist}); // WARNING: Using default pins and max distance`;
      }

      var funcCode =
      `long ${funcName}() {
  // Get the raw ping time in microseconds
  unsigned int pingTime = ${clean_var_name}.ping();
  
  // Convert ping time to distance in centimeters
  return ${clean_var_name}.convert_cm(pingTime);
  // Note: Returns 0 if no echo received within MAX_DISTANCE
}`;
      Blockly.Arduino.definitions_['func_' + funcName] = funcCode;
  }

  // Generate the code to call the specific function
  var code = `${funcName}()`;
  return [code, Blockly.Arduino.ORDER_UNARY_POSTFIX]; // Function call order
};